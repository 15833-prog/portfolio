// ปุ่มเปิด-ปิดเมนู (สารบัญ) บนจอมือถือ
document.addEventListener("DOMContentLoaded", function () {
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".toc-nav");

  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      nav.classList.toggle("open");
      const isOpen = nav.classList.contains("open");
      toggle.textContent = isOpen ? "ปิดเมนู ✕" : "สารบัญ ☰";
    });

    // ปิดเมนูอัตโนมัติเมื่อคลิกลิงก์ (เฉพาะจอมือถือ)
    nav.querySelectorAll(".toc-link").forEach(function (link) {
      link.addEventListener("click", function () {
        if (window.innerWidth <= 860) {
          nav.classList.remove("open");
          toggle.textContent = "สารบัญ ☰";
        }
      });
    });
  }
});
